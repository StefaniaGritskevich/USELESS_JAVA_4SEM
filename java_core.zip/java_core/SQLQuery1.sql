create database Lab06;
use Lab06;
create table Book(
id int not null primary key,
authorth nvarchar(500),
pub_date datetime,
publication nvarchar(100)
)

create table Author(
id int not null primary key,
fio nvarchar(200) not null,
country nvarchar(100)
)

create table Authors_Books(
book_id int not null foreign key references Book(id),
author_id int not null foreign key references Author(id)
)