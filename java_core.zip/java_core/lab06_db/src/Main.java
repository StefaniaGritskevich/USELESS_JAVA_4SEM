import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException {


        DAO dao = new DAO();
        dao.logInfo();
        dao.getConnection();
        //dao.Query0();
        //dao.Authors(103,"Adam Young", "Nederland");
       // dao.insertBook(1, "Neil Geiman", "2022-03-18", "American Gods");
        /*dao.insertBook(2, "Tailer Skuf Brecotkin", "2024-03-18", "Ural Pelmeni");
        dao.insertBook(3, "Lev Tolstoi", "1969-03-18", "War and Piece");
        dao.insertBook(44, "Adam Young", "2019-09-24", "The Paperclips");
        dao.insertBook(45, "Neil Geiman", "1999-03-21", "Good Omens");
        dao.insertBook(46, "Neil Geiman", "1989-04-01", "NeverWhere");*/
        //dao.insertBook(33, "Lev Tolstoi", "2023-03-18", "Conflict");
       // dao.insertBook(34, "Igor Lenskiu", "2026-03-18", "Conflict");
       // dao.insertBook(36, "Igor Lenskiu", "2027-03-18", "Postament");
        //////////////////////////////////////////////////////////////////////
  /*      dao.Authors_Books(1,1);
        dao.Authors_Books(2,2);
        dao.Authors_Books(3,3);
        dao.Authors_Books(45,1);
        dao.Authors_Books(46,1);
        dao.Authors_Books(103,44);*/







        System.out.println("------------Query 1------------\n");
        dao.Query1();
        System.out.println("------------Query 2------------\n");
       dao.Query2();
       System.out.println("------------Query 3------------\n");
        System.out.println("Enter number of books: ");
        Scanner sc = new Scanner(System.in);
        int input = sc.nextInt();
        dao.Query3(input);

        System.out.println("------------Query 4------------\n");
        dao.Query4();
        dao.closeConnection();
    }
}