import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import org.apache.log4j.LogManager;
import org.apache.log4j.xml.DOMConfigurator;

import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;
public class DAO implements IConnect, IQuery {
    private String url;
    private String user;
    private String password;
    private Connection con;
    private Statement statement;
    private static final Logger logger = Logger.getLogger(Main.class);

    // LOG
    public void logInfo() {
        BasicConfigurator.configure();
        logger.info("Start Main");
    }
   

    public ArrayList<String> getProperties() {
        // сканируем файл database.properties с помощью ResourceBundle
        ResourceBundle resourceBundle = ResourceBundle.getBundle("database");
        url = resourceBundle.getString("database.url");
        user = resourceBundle.getString("database.username");
        password = resourceBundle.getString("database.password");

        ArrayList<String> prop = new ArrayList<String>();
        prop.add(url);
        prop.add(user);
        prop.add(password);
        return prop;
    }

    public Boolean getConnection() {


        try {
            logger.info("Connection to DB (func getConnection())");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://BLUEBOX-228;databaseName=Lab06;trustServerCertificate=true;encrypt=false;IntegratedSecurity=false";
            con = DriverManager.getConnection(connectionUrl, "sa", "1111");
            statement = con.createStatement();
            logger.info("Connection to DB successfully  (func getConnection())");
            return true;
        }
        catch(Exception ex) {
            logger.error("Error connection to DB (func getConnection())");
            System.out.println(ex);
            return false;
        }
    }

    public void closeConnection() {
        try {
            logger.info("Close connection to DB (func closeConnection())");
            con.close();
            logger.info("Connection with DB is closed (func closeConnection())");
        }
        catch (Exception ex) {
            logger.error("Closing error (func closeConnection())");
            System.out.println(ex);
        }
    }

    public void Query0() throws SQLException {
        try {
            ResultSet resultSet = statement.executeQuery(
                    "insert into Author(id,fio,country) VALUES (1,'Neil Geiman', 'America'),(2,'Tailer Skuf Brecotkin', 'SSSR'),(3,'Lev Tolstoi', 'Russia')"
            );
        } catch (Exception ex) {
            logger.error("ERROR in table Author (func Query0())");
            System.out.println(ex);

        }

    }

    public void insertBook(int id, String authorth, String pub_date, String publication) {
        try {

            String sql = "INSERT INTO Book (id, authorth, pub_date, publication) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = con.prepareStatement(sql);

            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, authorth);
            preparedStatement.setString(3, pub_date);
            preparedStatement.setString(4, publication);

            preparedStatement.executeUpdate();

            logger.info("Data successfully added in Book");

        } catch (SQLException ex) {
            logger.error("ERROR in books Books: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void Authors_Books(int book_id,int author_id){
        try {
            String sql = "INSERT INTO Authors_Books (book_id, author_id) VALUES (?, ?)";
            PreparedStatement preparedStatement = con.prepareStatement(sql);

            preparedStatement.setInt(1, book_id);
            preparedStatement.setInt(2, author_id);
            preparedStatement.executeUpdate();
            logger.info("Data successfully added in Book");

        } catch (SQLException ex) {
            logger.error("ERROR in  Authors_Books: " + ex.getMessage());
            ex.printStackTrace();
        }

    }

    public void Authors(int id,String fio, String country){
        try {

            String sql = "INSERT INTO Author(id, fio, country) VALUES (?, ?,?)";
            PreparedStatement preparedStatement = con.prepareStatement(sql);

            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, fio);
            preparedStatement.setString(3, country);
            preparedStatement.executeUpdate();
            logger.info("Data successfully added in Book");

        } catch (SQLException ex) {
            logger.error("ERROR in books Authors: " + ex.getMessage());
            ex.printStackTrace();
        }

    }



    //////////////////////////////////////////////////////////////////////////////////
    public String Query1() {
        // Найти все книги, вышедшие в текущем и прошлом году
        try {
            ResultSet resultSet = statement.executeQuery(
                    "select publication, authorth, pub_date\n" +
                            "from Book\n" +
                            "where pub_date between '2023-01-01' and '2024-12-31'"
            );


            while(resultSet.next()) {
                String title = resultSet.getString(1);
                String authors = resultSet.getString(2);
                String year = resultSet.getString(3);
                System.out.println("Tittle: " + title + ", Author: " + authors + ", Year: " + year);
            }
            return resultSet.toString();

        } catch (Exception ex) {
            logger.error("Error in Query1 (func Query1())");
            System.out.println(ex);
            return "";
        }
    }

    public void Query2() {

        try {
            ResultSet resultSet = statement.executeQuery(
                    "SELECT * FROM Author"
            );

            while(resultSet.next()) {
                String id = resultSet.getString(1);
                String full_name = resultSet.getString(2);
                String country = resultSet.getString(3);
                System.out.println("ID: " + id + ", Full_Name: " + full_name + ", County: " + country);
            }
        }
        catch (Exception ex) {
            logger.error("Error in Query 2 (func Query2())");
            System.out.println(ex);

        }
    }

    public void Query3(int n) {
        try {
            String sql = "SELECT a.fio, COUNT(*) as num_books\n" +
                    "FROM Author a \n" +
                    "JOIN Book b on a.fio = b.authorth\n" +
                    "GROUP BY a.fio\n" +
                    "HAVING COUNT(*) >= ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, n);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                String authorName = result.getString("fio");
                int numBooks = result.getInt("num_books");
                System.out.println(authorName + " has written " + numBooks + " books");
            }
        }
        catch (Exception ex) {
            logger.error("Error in Query 3 (func Query3())");
            System.out.println(ex);
        }


    }

    public void Query4()
    {
        try {
            System.out.println("Was deleted:\n");
            statement.executeUpdate(
                    "DELETE FROM Book " +
                            "WHERE pub_date > '2025-01-19'"
            );

            /*ResultSet resultSet = statement.executeQuery(
                    "select publication, authorth, pub_date\n" +
                            "from Book\n" +
                            "where pub_date > '2022-01-01'"
            );
*/


            ResultSet resultSet = statement.executeQuery(
                    "select publication, authorth, pub_date\n" +
                            "from Book\n" +
                            "where pub_date > '2022-01-01'"
            );

            while(resultSet.next()){
                String count = resultSet.getString(1);
                System.out.println("Rows affected: " + count);
            }
        }
        catch (Exception ex) {
            logger.error("Error in query4!");
            System.out.println("Error in query4!");
            System.out.println(ex);
        }
    }
}
