import java.sql.ResultSet;
import java.sql.SQLException;
public interface IQuery {
    public String Query1();
    public void Query0() throws SQLException;

    public void Query2();
    public void Query3(int n);
    public void Query4();
}
