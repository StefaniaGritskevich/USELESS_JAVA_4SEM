package by.belstu.it.Gritskevich;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World!");
       // TODO add a new method
        New_TextFunction obj = new New_TextFunction();
        for (int i=0; i<9; i++) {
            if (!(i <= -1))
                if (i<10)
                    System.out.println(i);

        }

        for (int count = 0; count < 10; count++) {
            System.out.println("Counter "+count);
        }

    }
}
