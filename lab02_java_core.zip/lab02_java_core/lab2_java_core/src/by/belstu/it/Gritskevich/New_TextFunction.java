package by.belstu.it.Gritskevich;

public class New_TextFunction {
    public int test;

    public int getTest() {
        return test;
    }

    public void setTest(int test) {
        this.test = test;
    }

    public String getValue() {
        extracted();
        return "Hello from First project";

    }

    public New_TextFunction() {
    }


    private void extracted() {
        System.out.println("dfghjkl");
    }
}
