package com.example.lab_13.Model;

public class MyData {
    public static int ThisID;
    public static String ThisName;
    public static boolean isRegister = false;
}
