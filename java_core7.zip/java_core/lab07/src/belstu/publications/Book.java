package belstu.publications;
import belstu.shop.Genre;
import belstu.shop.Publication;

import java.util.Date;

public class Book extends Publication {


    private Book_info bookInfo;

    public Book(String title, String author, float cost, int pages, Date datepubl, Genre genre) {
        super(title, author, cost, pages);
        bookInfo = new Book_info(datepubl, genre);
    }

    public Book_info getBookInfo() {
        return bookInfo;
    }


    public  class Book_info {

        private  Date Datepubl;

        public  Date getDatepubl() {
            return Datepubl;
        }

        public void setDatepubl(Date datepubl) {
            Datepubl = datepubl;
        }

        private static Genre Ganre;

        public Genre getGanre() {
            return Ganre;
        }

        public void setGanre(Genre ganre) {
            Ganre = ganre;
        }

        public Book_info(Date datepubl, Genre ganre ) {
            super();
            Datepubl = datepubl;
            Ganre = ganre;
        }



    }
    @Override
    public String toString() {
        return "Book: " +
                "title='" + getTitle() + '\'' +
                ", author='" + getAuthor() + '\'' +
                ", cost=" + getCost() +
                ", pages=" + getPages() +
                ", Datepubl=" + bookInfo.getDatepubl() +
                ", Ganre=" + bookInfo.getGanre();
    }


}
