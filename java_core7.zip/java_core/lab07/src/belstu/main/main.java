package belstu.main;

import belstu.exeption.AgeExeption;
import belstu.exeption.PublicationNotFoundException;
import belstu.exeption.StageExeption;
import belstu.publications.Book;
import belstu.publications.Card;
import belstu.publications.Magazine;
import belstu.shop.Genre;
import belstu.shop.PrintedEdition;
import belstu.shop.Publication;
import belstu.shop.Seller;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.LogManager;
import java.util.logging.Logger;


public class main {



    public static void main(String[] args) throws PublicationNotFoundException, AgeExeption,StageExeption {


       /* List<Publication> BookShop = new ArrayList<>();

        Date datepubl = new Date(1998 - 1900, 0, 1, 0, 0, 0);

        Book book1 = new Book("Good Omens", "Neil Gaiman", 25.25F, 301, datepubl, Genre.FANTASY);
        Book book2 = new Book("American Gods", "Neil Gaiman", 35.25F, 350, new Date(2023 - 1900, 10, 10, 0, 0, 0), Genre.FANTASY);
        Book book3 = new Book("Death in the plane", "Agata Christie", 25.25F, 301, new Date(1992 - 1900, 8, 13, 0, 0, 0), Genre.DETECTIVE);
        Magazine mag1 = new Magazine("Times", "PopStar", 12.99F, 102, "Politics");
        Card car1 = new Card("Happy Birthday", "Msr. Fell", 1.25F, 1, "Party");
        try {
            Seller Carl = new Seller("Carl", 21, 2);
            //Seller Bill = new Seller("Bill", 91, 28);
            //Seller Yui = new Seller ("Yui", 19, 0);

            System.out.println(Carl.toString());
            Carl.addPublication(BookShop, book1);
            Carl.addPublication(BookShop, book2);
            Carl.addPublication(BookShop, book3);
            Carl.addPublication(BookShop, mag1);
            Carl.addPublication(BookShop, car1);

            for (Publication Soho : BookShop) {
                System.out.println(Soho.toString());
            }

            float totalCost = PrintedEdition.getTotalCost(BookShop);
            System.out.println("Total cost of all publications: " + totalCost);


            System.out.println("Sort these books by date\n");
            //Создаём коллекцию книг

            List<Book> booksToSort = new ArrayList<>();

            booksToSort.add(book1);
            booksToSort.add(book2);
            booksToSort.add(book3);
            List<Book> sortedBooks = Carl.sortBooksByPublicationDate(booksToSort);
            for (Book book : sortedBooks) {
                System.out.println(book.toString());
            }
            try {
//                System.out.println("\nJack London's books: \n");
//    List<Publication> foundPublications = Carl.findAny(BookShop, "Jack London");
//    for (Publication pub : foundPublications) {
//        System.out.println(pub.toString());

                System.out.println("\nNeil Gaiman's books:\n");
                List<Publication> foundPublications1 = Carl.findAny(BookShop, "Neil Gaiman");
                for (Publication pub : foundPublications1) {
                    System.out.println(pub.toString());
                }
            } catch (PublicationNotFoundException mess) {
                System.out.println("Error: " + mess.getMessage());
                mess.printStackTrace();
            }

            Carl.sell(BookShop, "American Gods");
            Carl.sell(BookShop, "Times");
System.out.println("\n");
            for (Publication Soho : BookShop) {
                System.out.println(Soho.toString());
            }


        }catch (AgeExeption mess) {
            System.out.println("Error: " + mess.getMessage());
            mess.printStackTrace();
        } catch (StageExeption mess){
            System.out.println("Error: " + mess.getMessage());
            mess.printStackTrace();
        }*/

    }
    }





