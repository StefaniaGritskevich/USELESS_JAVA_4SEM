package belstu.Test;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

public class Data_test {
    @DataProvider(name = "testData")
    public Object[][] DataFromFile() {
        try {
            File inputFile = new File("D:\\java\\lab07\\java_core\\lab07\\src\\belstu\\Test\\data_test.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            NodeList nodeList = doc.getElementsByTagName("test");
            Object[][] testData = new Object[nodeList.getLength()][2];

            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);
                testData[i][0] = element.getElementsByTagName("input").item(0).getTextContent();
                testData[i][1] = element.getElementsByTagName("output").item(0).getTextContent();
            }
            return testData;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Test(dataProvider = "testData")
    public void test(String input, String expectedOutput) {
        int actualOutput = test_func(input);
        Assert.assertEquals(actualOutput, Integer.parseInt(expectedOutput));
        System.out.println("Input: " + input + ", Expected Output: " + expectedOutput + ", Actual Output: " + actualOutput);
    }

    public int test_func(String input) {
        return input.equals("input1") ? 1 : 2;
    }
}
