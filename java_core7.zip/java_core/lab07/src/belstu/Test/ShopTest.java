package belstu.Test;
import belstu.exeption.AgeExeption;
import belstu.exeption.PublicationNotFoundException;
import belstu.exeption.StageExeption;
import belstu.publications.Book;
import belstu.shop.Genre;
import belstu.shop.PrintedEdition;
import belstu.shop.Publication;
import belstu.shop.Seller;

import org.testng.annotations.*;
import static org.testng.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ShopTest {

    private Seller testSeller;
    private Book testBook;
    private String testname;
    private List<Publication> testBookShop;


    @BeforeSuite
    public static void showTestIsStart() {
        System.out.println("Tests are started!");
    }

    @AfterSuite
    public static void showTestIsEnd() {
        System.out.println("Tests are ended!");
    }


    @BeforeMethod public void  setUp()  {
        testSeller = new Seller("Carl", 21, 2);
        testBook = new Book("Death in the plane", "Agata Christie", 25.25F, 301, new Date(1992 - 1900, 8, 13, 0, 0, 0), Genre.DETECTIVE);
        testname = "Death in the plane";
        testBookShop = new ArrayList<>();
        testBookShop.add(new Book("Book1", "Author1", 10.0f, 100, new Date(2022 - 1900, 0, 1), Genre.FICTION));
        testBookShop.add(new Book("Book2", "Author2", 20.0f, 200, new Date(2021 - 1900, 0, 1), Genre.FANTASY));
    }

    @AfterMethod
    public void End() {
        testSeller = null;
        testBook = null;
        testname = null;
        System.out.println("Test is over!");

    }
    @BeforeTest
    public void createSeller(){
        // testSeller = new Seller("Carl", 21, 2);
        System.out.println("ShopTest start");
    }
    @AfterTest
    public void tearDown() {
        testBookShop = null;

    }


    @Test (enabled = false) // enabled = false
    public void addNewBook() {
        testSeller.addPublication(testBook);
        assertTrue(testSeller.BookShop.contains(testBook));
    }

    @Test(timeOut = 1000)
    public void testGetTotalCost() {
        float totalCost = PrintedEdition.getTotalCost(testBookShop);
        assertEquals(totalCost, 30.0f);
    }

    @Test
    public void sellBook(){
        testSeller.sell(testname);
        assertFalse(testSeller.BookShop.contains(testname));

    }

    @Test(expectedExceptions = PublicationNotFoundException.class)
    public void testFindAnyPublicationNotFound() throws PublicationNotFoundException {
       // List<Publication> publications = new ArrayList<>();
        testSeller.BookShop.add(new Book("Good Omens", "Neil Gaiman", 10.0f, 100, new Date(2022 - 1900, 0, 1), Genre.FICTION));
        testSeller.findAny(testSeller.BookShop,"Ural Pelmeni" /*"Neil Gaiman"*/ );
    }

@Test
    public void testSortBooksByPublicationDate() {
        List<Book> books = new ArrayList<>();
        books.add(new Book("Smoke And Mirrors", "Neil Gaiman", 10.0f, 100, new Date(2022 - 1900, 0, 1), Genre.FICTION));
        books.add(new Book("NeverWhere", "Neil Gaiman", 20.0f, 200, new Date(2021 - 1900, 0, 1), Genre.FANTASY));

        List<Book> sortedBooks = testSeller.sortBooksByPublicationDate(books);

        assertEquals(sortedBooks.get(0).getTitle(), "NeverWhere");
        assertEquals(sortedBooks.get(1).getTitle(), "Smoke And Mirrors");
    }



}
