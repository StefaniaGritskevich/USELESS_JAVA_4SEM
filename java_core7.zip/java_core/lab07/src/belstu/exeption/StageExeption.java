package belstu.exeption;

public class StageExeption extends  Exception {
    public StageExeption(String message){
        super(message);
    }
}
