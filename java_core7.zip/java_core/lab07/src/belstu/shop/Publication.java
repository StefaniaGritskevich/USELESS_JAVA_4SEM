package belstu.shop;

import java.util.ArrayList;
import java.util.List;

public abstract class Publication {
    private String title;
    private String author;
    private float cost;
    private int pages;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public Publication(String title, String author, float cost, int pages) {
        this.title = title;
        this.author = author;
        this.cost = cost;
        this.pages = pages;
    }

    @Override
    public String toString() {
        return "Publication:" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", cost=" + cost +
                ", pages=" + pages;
    }
}
