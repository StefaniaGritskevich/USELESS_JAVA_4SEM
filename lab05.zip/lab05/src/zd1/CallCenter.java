package zd1;
import java.util.ArrayList;


public class CallCenter {
private static final int ATTEMPTES = 5;
    ArrayList<Operator> operators;

    public CallCenter(ArrayList<Operator> operators) {
        this.operators = operators;
    }


    public synchronized Operator tryCall(Client client, int waitingTime) {
        int attempts = 0;
        boolean success = false; // флаг успешного звонка

        while (!success) {
            for (var operator : operators) {
                if (searchFree(operator, client)) {
                    return operator;
                }
            }

            if (!success) {
                try {
                    attempts++;
                    if (check_Attemptes(attempts, waitingTime, client)) {
                        return null;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }


    public boolean searchFree(Operator operator, Client client){
        if(operator.getClient() == null){
            operator.setClient(client);
            operators.remove(operator);
            return true;
        }

        return false;
    }

    public synchronized boolean check_Attemptes( int att, int waighttime, Client client) throws InterruptedException {
        if (att == ATTEMPTES) {
            System.out.println("Client " + client.getId() + " doesn't get free operator");
            wait(waighttime);
            return true;
        } else {
            System.out.println("Client " + client.getId() + " is waiting for free operator");
            wait(waighttime);
        }
        return false;
    }

    public synchronized void endcall(Operator operator){
        operator.setClient(null);
        operators.add(operator);
        notify();

    }

}
