package zd1;

public class Client implements  Runnable {
    private final static int WAITING_TIME = 200;
    private final int id;
    private CallCenter callCenter;

    public Client(int id, CallCenter callCenter) {
        this.id = id;
        this.callCenter = callCenter;
    }

    public int getId() {
        return id;
    }

    public CallCenter getCallCenter() {
        return callCenter;
    }

    public void setCallCenter(CallCenter callCenter) {
        this.callCenter = callCenter;
    }

    @Override
    public void run() {
        Operator operator = null;
        try {
            while (operator == null) {
                System.out.println("Client " + id + " tries to call");
                operator = callCenter.tryCall(this, WAITING_TIME);
            }
            System.out.println("Client " + id + " has a connection with operator " + operator.getId());
            operator.talk();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (operator != null) {
                System.out.println("Client " + id + " has ended call with operator " + operator.getId());
                callCenter.endcall(operator);
            }

        }
    }
}