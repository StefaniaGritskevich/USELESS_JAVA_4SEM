package zd2;


public class Car {
    private final int id;
    private static int counter = 0;
    private final Direction direction;

    public Car(Direction direction) {
        this.id = counter++;
        this.direction = direction;
    }

    public int getId() {
        return id;
    }

    public Direction getDirection() {
        return direction;
    }
}
