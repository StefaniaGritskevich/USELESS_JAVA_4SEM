package zd2;

public enum Direction {
    WEST,
    EAST
}
