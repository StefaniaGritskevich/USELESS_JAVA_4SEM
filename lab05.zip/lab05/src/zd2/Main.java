package zd2;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Road road = new Road();//создаём дорогу

        for (int i = 0; i < 10; i++) { //создаем 10 машин
            Direction direction;
            if (i < 4) { //для первых 4 машин
                direction = i < 2 ? Direction.WEST : Direction.EAST;
            } else {
                direction = i % 2 == 0 ? Direction.WEST : Direction.EAST;
            }
            Car car = new Car(direction);
            Thread carThread = new Thread(() -> {
                try {
                    Thread.sleep(new Random().nextInt(1000));
                    road.carArrived(car);
                    Thread.sleep(1000);
                    road.carPassed(car);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            carThread.start();
        }


    }
}