package zd2;
import java.util.concurrent.Semaphore;

public class Road {
    public static zd2.Direction Direction;
    private final Semaphore carsFromWest = new Semaphore(2); // Семафор для машин из западного направления
    private final Semaphore carsFromEast = new Semaphore(2); // Семафор для машин из восточного направления

    public void carArrived(Car car) throws InterruptedException {
        if (car.getDirection() == Direction.WEST) {
            System.out.println("Car " + car.getId() + " went from West");
            carsFromWest.acquire();
        } else {
            System.out.println("Car " + car.getId() + " went from East");
            carsFromEast.acquire();
        }
    }

    public void carPassed(Car car) {

        if (car.getDirection() == Direction.WEST) {
            System.out.println("Car " + car.getId() + " went to East");
            carsFromWest.release();
        } else {
            System.out.println("Car " + car.getId() + " went to West");
            carsFromEast.release();
        }
    }
}
