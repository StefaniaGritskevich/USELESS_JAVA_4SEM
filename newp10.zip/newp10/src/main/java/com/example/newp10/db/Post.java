package com.example.newp10.db;

public class Post {
    private int postID;
    private String postName;
    private String postAuthor;
    private int postRate;


    public Post(){};
    public Post(int postID, String postName, String postAuthor, int postRate) {
        this.postID = postID;
        this.postName = postName;
        this.postAuthor = postAuthor;
        this.postRate = postRate;
    }

    public int getPostID() {
        return postID;
    }

    public void setPostID(int postID) {
        this.postID = postID;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getPostAuthor() {
        return postAuthor;
    }

    public void setPostAuthor(String postAuthor) {
        this.postAuthor = postAuthor;
    }

    public int getPostRate() {
        return postRate;
    }

    public void setPostRate(int postRate) {
        this.postRate = postRate;
    }
}