package com.example.newp10;

import java.io.*;
import java.sql.ResultSet;
import java.time.LocalTime;
import java.util.Enumeration;

import com.example.newp10.db.*;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import javax.xml.transform.Result;

@WebServlet(name = "firstServlet", value = "/FirstServlet")
public class HelloServlet extends HttpServlet {
    private static final DateBase db = new DateBase();
    @Override
    public void init() throws ServletException {
        db.getConnection();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        db.ExecuteUpdate("delete from posts where id = " + id);
        HttpSession session = request.getSession();
        Chel user = (Chel)session.getAttribute("current_user");
        request.setAttribute("name", user.getLogin());
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String rating = request.getParameter("rating");
        String author = request.getParameter("author");
        int rs = db.ExecuteUpdate("insert into posts (name, rating, author) values ('"
                + name + "', " + rating + ", '" + author +"')");
        if(rs == 0){
            request.getRequestDispatcher("ErrorPage.jsp").forward(request, response);
        }
        HttpSession session = request.getSession();
        Chel user = (Chel)session.getAttribute("current_user");
        request.setAttribute("name", user.getLogin());
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}