///*
//package ts2;
//import java.net.*;
//import java.io.*;
//
//public class Server {
//    public static void main(String[] args) throws IOException {
//
//        ServerSocket serverSocket = new ServerSocket(8000);
//        int count = 0;
//        while (true) {
//            Socket client = serverSocket.accept();
//            System.out.println("Client accepted" + (++count));
//
//            BufferedWriter writer = new BufferedWriter(
//                    new OutputStreamWriter(client.getOutputStream()));
//
//            BufferedReader reader = new BufferedReader(
//                    new InputStreamReader(
//                            client.getInputStream()));
//            String request = reader.readLine();
//
//            String response = "HTTP/1.0 200 OK\n"+
//                    "Content-type: text/html\n"+
//                    "\n"+
//            "#" + count + "request lenth" + request.length();
//
//            writer.write(response);
//            writer.newLine();
//            writer.flush();
//            writer.close();
//            reader.close();
//            client.close();
//        }
//    }
//}
//*/

// Код сервера
// Код сервера
package ts2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    private static final int PORT = 8888;
    private static final int NUM_PLAYERS = 2;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running. Waiting for " + NUM_PLAYERS + " players...");
            System.out.println("Player1 is setter, player2 is guesser\n");

            Socket[] playerSockets = new Socket[NUM_PLAYERS];
            PrintWriter[] writers = new PrintWriter[NUM_PLAYERS];
            BufferedReader[] readers = new BufferedReader[NUM_PLAYERS];

            for (int i = 0; i < NUM_PLAYERS; i++) {
                playerSockets[i] = serverSocket.accept();

                System.out.println("Player " + (i + 1) + " connected: " + playerSockets[i]);
                writers[i] = new PrintWriter(playerSockets[i].getOutputStream(), true);
                readers[i] = new BufferedReader(new InputStreamReader(playerSockets[i].getInputStream()));
            }


            writers[0].println("Enter a number:");


            int secretNumber = Integer.parseInt(readers[0].readLine());
            if(secretNumber>100 || secretNumber < 0) {
                do {
                    writers[0].println("You should choose number from 0 to 100");
                    secretNumber = Integer.parseInt(readers[0].readLine());
                } while (secretNumber > 100 || secretNumber < 0);
            }


            writers[1].println("Try to guess a number from 1 to 100:");


            boolean continuePlaying = true;
            while (continuePlaying) {

                int guess = Integer.parseInt(readers[1].readLine());
                if(guess > 100 || guess < 0)
                    do{
                        writers[1].println("You should choose number from 0 to 100");
                        guess = Integer.parseInt(readers[1].readLine());
                    }
                while (guess > 100 || guess < 0);
                writers[0].println(guess);
                writers[0].flush();
                if(guess == secretNumber){
                    writers[1].println("Congratulations! You guessed the number! Tab Enter to leave game");
                    if (playerSockets[1] != null && playerSockets[1].isClosed()) {
                        writers[0].println("What's a pity, you are looser today:(  Tab Enter to leave game");
                    }

                    serverSocket.close();
                    break;
                }
                do {

                    String command = readers[0].readLine();

                    if (command.equals("bigger")) {
                        if (guess > secretNumber) {
                            writers[0].println("You entered the wrong command. The number is smaller than " + guess);
                        } else {
                            writers[1].println("bigger");
                            break;
                        }
                    } else if (command.equals("smaller")) {
                        if (guess < secretNumber) {
                            writers[0].println("You entered the wrong command. The number is bigger than " + guess);
                        } else {
                            writers[1].println("smaller");
                            break;
                        }

                    } else {
                        writers[0].println("Invalid command. Please enter 'bigger', 'smaller', or 'win'.");
                    }
                } while (true);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
