package ts1;

public class Main {
    public static void main(String[] args) {
        var connect = new Connect();
        connect.getLocalHost();
        connect.getByName("www.wikipedia.org");
        byte[] ip = {(byte)127, (byte)0, (byte)0, (byte)1};
        connect.getByAddress("Loopback", ip);
        System.out.println("");
        connect.readHTML("https://en.wikipedia.org/wiki/Doctor_Who");
        connect.getInfo("https://en.wikipedia.org/wiki/Doctor_Who");
    }
}