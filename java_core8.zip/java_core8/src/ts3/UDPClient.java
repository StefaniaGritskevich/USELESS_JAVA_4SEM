package ts3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UDPClient{
    /* Порт сервера, к которому собирается
  подключиться клиентский сокет */
    public final static int SERVICE_PORT = 50001;

    public static void main(String[] args) throws IOException{
        try{
      /* Создаём экземпляр клиентского сокета. */
            DatagramSocket clientSocket = new DatagramSocket();

            // Получаем IP-адрес сервера
            InetAddress IPAddress = InetAddress.getByName("localhost");

            // Создаём соответствующие буферы
            byte[] sendingDataBuffer = new byte[1024];
            byte[] receivingDataBuffer = new byte[1024];

      /* Преобразуем данные в байты
       и размещаем в буферах */
            String sentence = "Hello from UDP client";
            sendingDataBuffer = sentence.getBytes();

            // Создаём UDP-пакет
            DatagramPacket sendingPacket = new DatagramPacket(sendingDataBuffer,sendingDataBuffer.length,IPAddress, SERVICE_PORT);

            clientSocket.send(sendingPacket);


            DatagramPacket receivingPacket = new DatagramPacket(receivingDataBuffer,receivingDataBuffer.length);
            clientSocket.receive(receivingPacket);

            String receivedData = new String(receivingPacket.getData());
            System.out.println("Sent from the server: "+receivedData);


            clientSocket.close();
        }
        catch(SocketException e) {
            e.printStackTrace();
        }
    }
}