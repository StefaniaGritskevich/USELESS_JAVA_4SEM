package ts3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UDPServer{

    public final static int SERVICE_PORT=50001;

    public static void main(String[] args) throws IOException{
        try{

            DatagramSocket serverSocket = new DatagramSocket(SERVICE_PORT);

      /* Буферы для хранения отправляемых и получаемых данных. Хранят данные в случае задержек связи */
            byte[] receivingDataBuffer = new byte[1024];
            byte[] sendingDataBuffer = new byte[1024];

            /* UDP-пакет для хранения клиентских данных с использованием буфера для полученных данных */
            DatagramPacket inputPacket = new DatagramPacket(receivingDataBuffer, receivingDataBuffer.length);
            System.out.println("Waiting for a client to connect...");

            // Получаем данные от клиента и сохраните их в inputPacket
            serverSocket.receive(inputPacket);

            String receivedData = new String(inputPacket.getData());
            System.out.println("Sent from the client: "+receivedData);

            sendingDataBuffer = receivedData.toUpperCase().getBytes();

            // Получаем IP-адрес и порт клиента
            InetAddress senderAddress = inputPacket.getAddress();
            int senderPort = inputPacket.getPort();

            // Создаём новый UDP-пакет с данными, чтобы отправить их клиенту
            DatagramPacket outputPacket = new DatagramPacket(
                    sendingDataBuffer, sendingDataBuffer.length,
                    senderAddress,senderPort
            );


            serverSocket.send(outputPacket);

            serverSocket.close();
        }
        catch (SocketException e){
            e.printStackTrace();
        }
    }
}
