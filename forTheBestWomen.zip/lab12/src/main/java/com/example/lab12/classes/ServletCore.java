package com.example.lab12.classes;

import com.example.lab12.classes.Students;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "ServletCore", value = "/ServletCore")
public class ServletCore extends HttpServlet {

    ArrayList<Students> students = new ArrayList<>();

    public void init(){

    };
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
students.add(new Students("Mikhael", 22, "m"));
        students.add(new Students("Azazel", 19, "m"));
        students.add(new Students("Omara", 22, "f"));
        request.setAttribute("lst", students);
        request.getRequestDispatcher("Core.jsp").forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
