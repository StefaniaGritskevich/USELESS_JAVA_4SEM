package com.example.lab12.UsTegs;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspTag;
@SuppressWarnings("serial")
public class Hrisubmit extends TagSupport{
    @Override
    public int doStartTag() throws JspException
    {
        JspWriter out = pageContext.getOut();
        try {
            out.println("<input type=\"submit\" required value=\"Вход\" name=\"input\">\n" +
                    " <input type=\"submit\" required value=\"Регистрация\" name=\"registration\">");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return SKIP_BODY;
    }
}
