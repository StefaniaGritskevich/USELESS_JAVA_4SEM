//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package belstu.main;

import belstu.exeption.AgeExeption;
import belstu.exeption.PublicationNotFoundException;
import belstu.exeption.StageExeption;
import belstu.publications.Book;
import belstu.publications.Card;
import belstu.publications.Magazine;
import belstu.shop.Genre;
import belstu.shop.Publication;
import belstu.shop.Seller;
import belstu.xmlparser.StaxStreamProcessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.SAXException;

public class main {
 public main() {
 }

 public static void main(String[] args) throws PublicationNotFoundException, AgeExeption, StageExeption, IOException, SAXException {
  List<Publication> BookShop = new ArrayList();
  Date datepubl = new Date(98, 0, 1, 0, 0, 0);
  Book book1 = new Book("Good Omens", "Neil Gaiman", 25.25F, 301, datepubl, Genre.FANTASY);
  Book book2 = new Book("American Gods", "Neil Gaiman", 35.25F, 350, new Date(123, 10, 10, 0, 0, 0), Genre.FANTASY);
  Book book3 = new Book("Death in the plane", "Agata Christie", 25.25F, 301, new Date(92, 8, 13, 0, 0, 0), Genre.DETECTIVE);
  Magazine mag1 = new Magazine("Times", "PopStar", 12.99F, 102, "Politics");
  Card car1 = new Card("Happy Birthday", "Msr. Fell", 1.25F, 1, "Party");

  try {
   Seller Carl = new Seller("Carl", 21, 2);
   System.out.println(Carl.toString());
   Carl.addPublication(BookShop, book1);
   Carl.addPublication(BookShop, book2);
   Carl.addPublication(BookShop, book3);
   Carl.addPublication(BookShop, mag1);
   Carl.addPublication(BookShop, car1);
   Book book4 = new Book("Good Omens", "Neil Gaiman", 25.25F, 301, Genre.FANTASY);
   Book book5 = new Book("American Gods", "Neil Gaiman", 35.25F, 350, Genre.MYSTERY);
   Book book6 = new Book("Death in the plane", "Agata Christie", 25.25F, 301, Genre.SCIENCE_FICTION);
   List<Book> books = new ArrayList();
   books.add(book4);
   books.add(book5);
   books.add(book6);
   ObjectMapper mapper = new ObjectMapper();
   String json = mapper.writeValueAsString(books);
   FileWriter fileWriter = new FileWriter("bookshop.json");
   fileWriter.write(json);
   fileWriter.close();
   System.out.println("\nData have been serialized to bookshop.json\n");
   FileReader fileReader = new FileReader("bookshop.json");
   Book[] pubArray = (Book[])mapper.readValue(fileReader, Book[].class);
   fileReader.close();
   Book[] var18 = pubArray;
   int var19 = pubArray.length;

   Book b2;
   for(int var20 = 0; var20 < var19; ++var20) {
    b2 = var18[var20];
    System.out.println(b2.toString());
   }

   Book b1 = new Book();
   Magazine m1 = new Magazine();
   Card c1 = new Card();
   b2 = new Book();
   List<Publication> booklist = Arrays.asList(b1, m1, c1, b2);
   ArrayList<String> book_tittle = new ArrayList();
   ArrayList<String> book_author = new ArrayList();
   ArrayList<String> cost = new ArrayList();
   ArrayList<String> pages = new ArrayList();
   ArrayList<String> genre = new ArrayList();
   StaxStreamProcessor.addNamesToList("Tittle", book_tittle);
   StaxStreamProcessor.addNamesToList("Author", book_author);
   StaxStreamProcessor.addNamesToList("Cost", cost);
   StaxStreamProcessor.addNamesToList("Pages", pages);
   StaxStreamProcessor.addNamesToList("Genre", genre);

   for(int i = 0; i < booklist.size(); ++i) {
    ((Publication)booklist.get(i)).setTitle((String)book_tittle.get(i));
    ((Publication)booklist.get(i)).setAuthor((String)book_author.get(i));
    ((Publication)booklist.get(i)).setCost((float)Double.parseDouble((String)cost.get(i)));
    ((Publication)booklist.get(i)).setPages(Integer.parseInt((String)pages.get(i)));
    ((Publication)booklist.get(i)).setGenre(Genre.valueOf(((String)genre.get(i)).replace("Genre.", "")));
   }

   System.out.println("\n\nXML Books:");
   for (Publication book: booklist)
    System.out.println("Tittle:  " + book.getTitle() + "\nAuthor:    " + book.getAuthor() +
            " \nCost:  " + book.getCost() + "\nPages: " + book.getPages() + "\nGenre"+book.getGenre());

   File schemaFile = new File("D:\\java\\lab04\\lab04\\lab4\\files\\validation.xsd");
   Source xmlFile = new StreamSource(new File("D:\\java\\lab04\\lab04\\lab4\\files\\BookShop.xml"));
   SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
   Schema schema = schemaFactory.newSchema(schemaFile);
   Validator validator = schema.newValidator();
   validator.validate(xmlFile);
   System.out.println("\nXML SUCSSES XSD!");
   /////////////////////////////////
   List<Book> api = new ArrayList();
   api.add(book4);
   api.add(book5);
   api.add(book6);
   var list = api.stream()
           .filter(l -> l.getCost() < 35f).toList();
   for (Book item : list){
    System.out.println((item.toString()));}
   System.out.println("\n");
           var list1 = api.stream()
           .map(Book::getAuthor).toList();
           for (String item : list1){
    System.out.println((item.toString()));}
   System.out.println("\n");
           var list2 = api.stream()
           .limit(1).toList();
           for (Book item : list2){
    System.out.println((item.toString()));}
   var list3 = api.stream()
           .anyMatch(l -> l.getPages() == 301);    System.out.println(list3);
  } finally {
   System.out.println("Happy House!!!))))");
  }
 }
}
