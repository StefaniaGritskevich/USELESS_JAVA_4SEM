package belstu.exeption;

public class AgeExeption extends Exception {
    public AgeExeption(String message) {
        super(message);
    }
}
