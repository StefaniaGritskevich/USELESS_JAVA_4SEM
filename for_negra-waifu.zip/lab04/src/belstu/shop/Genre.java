package belstu.shop;

public enum Genre {
    FICTION,
    SCIENCE_FICTION,
    MYSTERY,
    ROMANCE,
    FANTASY,
    DETECTIVE
}

