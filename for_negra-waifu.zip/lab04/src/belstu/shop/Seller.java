package belstu.shop;

import belstu.exeption.AgeExeption;
import belstu.exeption.PublicationNotFoundException;
import belstu.exeption.StageExeption;
import belstu.publications.Book;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Seller implements PrintedEdition {
    private String name;
    private int age;
    private int stage;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getStage() {
        return stage;
    }

    public void setStage(int stage) {
        this.stage = stage;
    }

    public Seller(String name, int age, int stage) throws AgeExeption, StageExeption {
        if(age > 80) {
            throw new AgeExeption("Unfortunately, you can not work in the bookshop:(");
        }
        if(stage < 1){
            throw new StageExeption("Sorry, you have not enough experience to work with us:(\n");
        }
        this.name = name;
        this.age = age;

        this.stage = stage;
    }

    @Override
    public String toString() {
        return "Good morning, my name is " + getName() + " I'm " + getAge() +
                " And I've been working here already " + getStage() + " years." +
                " How can I help you?)";
    }

    public List<Book> sortBooksByPublicationDate(List<Book> books) {
        books.sort(Comparator.comparing(book -> book.getBookInfo().getDatepubl()));
        return books;
    }

    public List<Publication> findAny(List<Publication> chtivo, String name) throws PublicationNotFoundException {
        List<Publication> result = new ArrayList<>();
        for (Publication publication : chtivo) {
            if (publication instanceof Book && ((Book) publication).getAuthor().equals(name)) {
                result.add(publication);
            }
        }
        if(result.isEmpty()){
            throw new PublicationNotFoundException("Publication with author" + name + " not found");
        }
        return result;
    }

    public List<Publication> sell(List<Publication> BookShop, String name) {
        Iterator<Publication> iterator = BookShop.iterator();
        while (iterator.hasNext()) {
            Publication publication = iterator.next();
            if (publication instanceof Publication && ((Publication) publication).getTitle().equals(name)) {
                iterator.remove();
                System.out.println(name + " has been sold. Have a good day!");
            }
        }
        return BookShop;
    }

    public void  addPublication(List<Publication> BookShop, Publication pop){
        BookShop.add(pop);
        System.out.println("New publication has been aded");
    }


}

