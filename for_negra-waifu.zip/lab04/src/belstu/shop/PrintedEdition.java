package belstu.shop;

import belstu.exeption.PublicationNotFoundException;
import belstu.publications.Book;

import java.util.List;

public interface PrintedEdition {
    void addPublication(List<Publication> BookShop, Publication pop);
    List<Book> sortBooksByPublicationDate(List<Book> books);
    List<Publication> findAny(List<Publication> chtivo, String name) throws PublicationNotFoundException;
    List<Publication> sell(List<Publication> BookShop,String name);

    public static float getTotalCost(List < Publication > BookShop) {
        float totalCost = 0.0f;

        for (Publication publication : BookShop) {
            totalCost += publication.getCost();
        }

        return totalCost;
    }


}
