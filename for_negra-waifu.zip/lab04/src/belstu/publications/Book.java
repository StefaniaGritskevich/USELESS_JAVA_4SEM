package belstu.publications;
import belstu.shop.Genre;
import belstu.shop.Publication;

import java.util.Date;

public class Book extends Publication {

    public static Genre Ganre;


    public Book() {

    }

    public Book(String title, String author, float cost, int pages, Genre G) {
        super(title, author, cost, pages);
        Ganre = G;


    }

    private Book_info bookInfo;

    public Book(String title, String author, float cost, int pages, Date datepubl, Genre genre) {
        super(title, author, cost, pages);
        bookInfo = new Book_info(datepubl, genre);
    }

    public Book_info getBookInfo() {
        return bookInfo;
    }


    public  class Book_info {

        private  Date Datepubl;

        public  Date getDatepubl() {
            return Datepubl;
        }

        public void setDatepubl(Date datepubl) {
            Datepubl = datepubl;
        }



        public Book_info(Date datepubl, Genre ganre ) {
            super();
            Datepubl = datepubl;
            Ganre = ganre;
        }



    }
    @Override
    public String toString() {
        return "Book: " +
                "title='" + getTitle() + '\'' +
                ", author='" + getAuthor() + '\'' +
                ", cost=" + getCost() +
                ", pages=" + getPages();
    }



}
