package belstu.publications;
import belstu.shop.Publication;

public class Magazine extends Publication {

    private String Category;

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public Magazine(String title, String author, float cost, int pages, String category) {
        super(title, author, cost, pages);
        Category = category;
    }

    public Magazine() {
    }

    @Override
    public String toString() {
        return super.toString() + ", Category=" + getCategory();
    }
}
