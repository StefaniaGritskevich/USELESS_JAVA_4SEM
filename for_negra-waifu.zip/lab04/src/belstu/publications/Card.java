package belstu.publications;
import belstu.shop.Publication;
public class Card extends Publication {
    private String style;

    public String getStyle() {
        return style;
    }

    public void setStyle(String Style) {
        style = Style;
    }

    public Card(String title, String author, float cost, int pages, String style) {
        super(title, author, cost, pages);
        this.style = style;
    }

    public Card() {
    }

    @Override
    public String toString() {
        return "Card: " +
                "title='" + getTitle() + '\'' +
                ", author='" + getAuthor() + '\'' +
                ", cost=" + getCost() +
                ", pages=" + getPages() +
                ", Style=" + getStyle();
    }
}
