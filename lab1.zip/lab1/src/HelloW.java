public class HelloW {
    public static void main(String[] args) {
        // Display "Hello World!"
        System.out.println("Hello World!");

    }
}
